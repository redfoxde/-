create definer = root@localhost trigger after_insert_order
    after insert
    on booking
    for each row
begin 
        UPDATE rooms
            SET STATUS='已预定'
        WHERE room_number=NEW.room_number;
    end;

